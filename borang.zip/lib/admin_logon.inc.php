<?php
/**
 * admin_logon class
 * Class for user authentication
 *
 * Copyright (C) 2007,2008  Arie Nugraha (dicarve@yahoo.com)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
 *
 */

class admin_logon
{
    private $obj_db = false;
    protected $username = '';
    protected $password = '';
    protected $auth_method = 'native';
    protected $user_info = array();
    public $real_name = '';
    public $ip_check = false;
    public $ip_allowed = array();
    public $errors = '';


    /**
     * Class Constructor
     *
     * @param   string  $str_username
     * @param   string  $str_password
     * @param   string  $str_auth_method
     * @return  void
     */
    public function __construct($str_username, $str_password, $str_auth_method = 'native') {
        $this->username = trim($str_username);
        $this->password = trim($str_password);
        $this->auth_method = $str_auth_method;
    }


    /**
     * Method to check user validity
     *
     * @param   object  $obj_db
     * @return  void
     */
    public function adminValid($obj_db) {
        $this->obj_db = $obj_db;
        $_check_login = call_user_func(array($this, $this->auth_method.'Login'));
        // check if the user exist in database
        if (!$_check_login) {
            return false;
        }

        // if the ip checking is enabled
        if ($this->ip_check) {
            if (!in_array($_SERVER['REMOTE_ADDR'], $this->ip_allowed)) {
                $this->errors = 'IP not allowed to login';
                return false;
            }
        }

        $this->real_name = $this->user_info['realname'];
        // fill all sessions var
        $_SESSION['uid'] = $this->user_info['user_id'];
        $_SESSION['uname'] = $this->user_info['username'];
        $_SESSION['realname'] = $this->user_info['realname'];
        if (!empty($this->user_info['groups'])) {
            $_SESSION['groups'] = @unserialize($this->user_info['groups']);
            // fetch group privileges
            foreach ($_SESSION['groups'] as $group_id) {
                $_priv_q = $obj_db->query("SELECT ga.*,mdl.module_path FROM group_access AS ga
                    LEFT JOIN mst_module AS mdl ON ga.module_id=mdl.module_id WHERE ga.group_id=$group_id");
                while ($_priv_d = $_priv_q->fetch_assoc()) {
                    if ($_priv_d['r']) {
                        $_SESSION['priv'][$_priv_d['module_path']]['r'] = true;
                    }
                    if ($_priv_d['w']) {
                        $_SESSION['priv'][$_priv_d['module_path']]['w'] = true;
                    }
                }
            }
        } else {
            $_SESSION['groups'] = null;
        }

        $_SESSION['logintime'] = time();
        // session vars needed by some application modules
        $_SESSION['temp_loan'] = array();
        $_SESSION['biblioAuthor'] = array();
        $_SESSION['biblioTopic'] = array();
        $_SESSION['biblioAttach'] = array();

        // save md5sum of  current application path
        $server_addr = isset($_SERVER['SERVER_ADDR']) ? $_SERVER['SERVER_ADDR'] : (isset($_SERVER['LOCAL_ADDR']) ? $_SERVER['LOCAL_ADDR'] : gethostbyname($_SERVER['SERVER_NAME']));
        $_SESSION['checksum'] = defined('UCS_BASE_DIR')?md5($server_addr.UCS_BASE_DIR.'admin'):md5($server_addr.SENAYAN_BASE_DIR.'admin');

        // update the last login time
        $obj_db->query("UPDATE user SET last_login='".date("Y-m-d H:i:s")."',
            last_login_ip='".$_SERVER['REMOTE_ADDR']."'
            WHERE user_id=".$this->user_info['user_id']);

        return true;
    }


    /**
     * LDAP/Active directory login
     *
     * @return  boolean
     */
    protected function ldapLogin() {
        global $ldap_configs;
        if (!function_exists('ldap_connect')) {
            $this->errors = 'LDAP library is not installed yet!';
            return false;
        }
        // connect to Directory Server
        $_ds = $ldap_configs['ldap_port']?ldap_connect($ldap_configs['ldap_server'], $ldap_configs['ldap_port']):ldap_connect($ldap_configs['ldap_server']);

        // check LDAP options
        if ($ldap_configs['ldap_options']) {
            foreach ($ldap_configs['ldap_options'] as $_opt) {
                @ldap_set_option($_ds, $_opt[0], $_opt[1]);
            }
        }

        // LDAP Connection check
        if (!$_ds) {
            $this->errors = 'Failed to connect to LDAP server';
            return false;
        }

        // binding
        $_bind = @ldap_bind($_ds,
            str_ireplace('#loginUserName', $this->username, $ldap_configs['ldap_bind_dn']),
            $this->password);

        if (!$_bind) {
            $this->errors = 'Failed to bind to directory server!';
            return false;
        }

        $_filter = str_ireplace('#loginUserName', $this->username, $ldap_configs['ldap_search_filter']);

        // run query
        // $_search = @ldap_search($_ds, $ldap_configs['ldap_base_dn'], $_filter);
        $_search = @ldap_search($_ds, str_ireplace('#loginUserName', $this->username, $ldap_configs['ldap_bind_dn']), $_filter);
        if (!$_search) {
            $this->errors = 'LDAP search failed because of error!';
            return false;
        }

        // get query entry
        $_entries = @ldap_get_entries($_ds, $_search);
        if ($_entries) {
            $_username = $_entries[0][$ldap_configs['userid_field']][0];
            // check if User data exists in database
            $_check_q = $this->obj_db->query("SELECT u.user_id, u.username, u.realname, u.groups
                FROM user AS u WHERE u.username='".$_username."'");
            if ($_check_q->num_rows < 1) {
                $this->errors = 'You don\'t have enough privileges to enter this section!';
                return false;
            } else {
                $this->user_info = $_check_q->fetch_assoc();
            }
        } else {
            $this->errors = 'LDAP Record not found!';
            return false;
        }

        // closing connection
        ldap_close($_ds);
        return true;
    }


    /**
     * Native database checking login method
     *
     * @return  boolean
     */
    protected function nativeLogin() {
        $_sql_librarian_login = sprintf("SELECT
            u.user_id, u.username,
            u.realname, u.groups
            FROM user AS u
            WHERE u.username='%s'
                AND u.passwd=MD5('%s')", $this->obj_db->escape_string($this->username), $this->obj_db->escape_string($this->password));
        $_user_q = $this->obj_db->query($_sql_librarian_login);
        // error check
        if ($this->obj_db->error) {
            $this->errors = 'Failed to query user data from database with error: '.$this->obj_db->error;
            return false;
        }
        // result check
        if ($_user_q->num_rows < 1) {
            $this->errors = 'Username or Password not exists in database!';
            return false;
        }
        // get user info
        $this->user_info = $_user_q->fetch_assoc();
        return true;
    }
}
