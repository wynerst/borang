<?php
echo '
	<div class="span3 pull-right" >
    <ul class="nav nav-pills">
    <li>
    <a href="csr.php">Home</a>
    </li>
    <li><a href="index.php">Filter</a></li>
    <li><a href="find.php">Find</a></li>
    <li class="active"><a href="input.php">DataEntry</a></li>
    </ul></div>';


